package com.es2.equipe4.repository;

import com.es2.equipe4.model.EventLecture;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EventLectureRepository extends JpaRepository<EventLecture, Integer> {}

